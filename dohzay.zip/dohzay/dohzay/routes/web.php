<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/link', function () {
    Artisan::call('storage:link');
});

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

// User Routes
Route::get('/register','RegisterController@create')->name('register');
Route::post('/register','RegisterController@store')->name('createUser');
Route::get('/login','LoginController@index')->name('login');
Route::post('/login','LoginController@login')->name('userLogin');

// Store Routes
Route::get('/store','StoreController@index')->name('store')->middleware('seller');
Route::get('/store/register','StoreController@create')->name('registerStore')->middleware('seller');
Route::post('/store/register','StoreController@store')->name('createStore')->middleware('seller');

// Menu Routes
Route::get('/menu/mylist','MenuController@index')->name('myMenuList')->middleware('seller');
Route::get('/menu/post','MenuController@post')->name('post')->middleware('seller');
Route::post('/menu/post','MenuController@store')->name('postMenu')->middleware('seller');

// Posts Routes
Route::get('/posts','PostsController@index')->name('posts')->middleware('buyer');
Route::get('/posts/township','PostsController@filtertownship')->name('filtertownship')->middleware('buyer');


// Cart Routes
Route::post('/carts/add','CartController@add')->name('addToCart')->middleware('buyer');


// Counter Routes
Route::get('/counter','CounterController@index')->name('counter')->middleware('buyer');
Route::get('/counter/viewCart/{voucher_id}','CounterController@viewCart')->name('viewCart')->middleware('buyer');
Route::post('/counter/confirmOrder','CounterController@confirmOrder')->name('confirmOrder')->middleware('buyer');
Route::get('/counter/order/history','CounterController@orderHistory')->name('orderHistory')->middleware('buyer');
Route::get('/counter/orderHistory/{voucher_id}','CounterController@detailOrderHistory')->name('detailOrderHistory')->middleware('buyer');

// Cashier Routes
Route::get('/cashiers/viewTodayOrders','CashiersController@todayOrders')->name('viewTodayOrders')->middleware('seller');
Route::get('/cashiers/viewOrders','CashiersController@viewOrders')->name('viewOrders')->middleware('seller');
Route::get('/cashiers/viewVoucher/{voucher_id}','CashiersController@viewVoucher')->name('viewVoucher')->middleware('seller');
Route::post('/cashiers/acceptOrder','CashiersController@acceptOrder')->name('acceptOrder')->middleware('seller');
Route::post('/cashiers/cancelOrder','CashiersController@cancelOrder')->name('cancelOrder')->middleware('seller');

