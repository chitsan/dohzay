<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-3">
                <div class="card bg-dark text-white shadow ">
                    <div class="card-header text-center">
                        <h3 class="mt-1"><?php echo e($food->name); ?></h5>
                    </div>

                    <div class="card-body ">
                        <?php $image = $food->images[0]->url ?>
                        <img src="<?php echo e(asset('storage/images/foods/'.$image)); ?>" alt="" class="img-fluid">
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\dohzay\resources\views/foods/myFoodList.blade.php ENDPATH**/ ?>