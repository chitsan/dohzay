<!-- ADD Cart Modal -->
<div class="modal fade" id="confirmOrderModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-sm">
    <div class="modal-content bg-dark text-white">
        <div class="modal-header border-dark">
            <h3 class="modal-title" id="exampleModalLabel">Confirm Order</h3>
            <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form method="post" action=" <?php echo e(route('confirmOrder')); ?>">
        
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <div class="modal-body border-dark text-left">
                <div class="form-group">
                    <label>Township</label>
                    <input type="hidden" class="form-control form-dark" id="voucher_id" name="voucher_id">
                    <select name="township_id" id="township" class="form-control form-dark shadow">
                        <?php $__currentLoopData = $townships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $township): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($township->id); ?>"><?php echo e($township->township); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>
                <div class="form-group">
                    <label>Phone</label>
                    <input type="string" class="form-control form-dark shadow" name="phone" id="phone" required>
                </div>
                <div class="form-group">
                    <label>Message</label>
                    <textarea name="message" id="message" class="form-control form-dark shadow" cols="10" rows="3" required></textarea>
                </div>

                <div class="form-group">
                    <label>Address</label>
                    <textarea name="address" id="address" class="form-control form-dark shadow" cols="10" rows="3" required></textarea>
                </div>
                <hr class="bg-secondary">
                <button type="submit" class="btn btn-outline-info btn-block">Confirm Order</button>
                <button type="button" class="btn btn-outline-secondary btn-block" data-dismiss="modal">Close</button>
            </div>
        </form>
    </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){

        $('.btn-confirm').on('click', function() {
            $('#confirmOrderModal').modal('show');


            $voucher_id = $(this).closest('div').find('.voucher-id');


            document.querySelector('#voucher_id').value = $voucher_id.val();
        });

    });


</script>
<?php /**PATH D:\htdocs\dohzay\resources\views/modal/confirmOrder.blade.php ENDPATH**/ ?>