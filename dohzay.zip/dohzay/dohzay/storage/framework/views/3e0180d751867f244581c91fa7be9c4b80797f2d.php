<?php $__env->startSection('content'); ?>
<div class="container pt-5">
    <div class="row justify-content-center text-center">
        <div class="col-md-4">
            <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card bg-dark text-secondary">
                <div class="card-header">
                    <div class="form-inline justify-content-center">
                        <h2 class="text-right mt-2 mr-2">
                            Order History
                        </h2>

                        <a href=" <?php echo e(route('posts')); ?>" class="btn btn-danger btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14.9" height="12.2" viewBox="0 0 24.9 22.2">
                                <g id="back" transform="translate(-821.1 -1467.9)">
                                  <path id="Path_481" data-name="Path 481" d="M846,1482.7a16.165,16.165,0,0,1-1.8,6.2c0,.1-.1.2-.1.3a.758.758,0,0,1-.2.4c-.1.1-.1.2-.2.3-.1.2-.2.2-.4.2a.353.353,0,0,1-.4-.4v-.7c0-.6.1-1.2.1-1.7a18.088,18.088,0,0,0-.2-2.5,8.392,8.392,0,0,0-.7-1.9,7.553,7.553,0,0,0-1.1-1.4,7.839,7.839,0,0,0-1.5-1,9.5,9.5,0,0,0-1.8-.6l-2.1-.3a17.728,17.728,0,0,0-2.4-.1H830v3.5a.851.851,0,0,1-1.5.6l-7.1-7.1a.75.75,0,0,1,0-1.2l7.1-7.1a.9.9,0,0,1,1.5.6v3.5h3.1c6.6,0,10.6,1.9,12.1,5.6A14.635,14.635,0,0,1,846,1482.7Z" fill="#fff"/>
                                </g>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if( count($vouchers) == 0): ?>
                        <p class="badge badge-danger"> You haven't make order yet! </p>
                    <?php endif; ?>
                    <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $sale_date = $voucher->sale_date;
                            $sale_date = date_create($sale_date);
                            $sale_date = date_format( $sale_date,'d/m/Y');
                        ?>
                        <a href="<?php echo e(route('detailOrderHistory',$voucher->id)); ?>">
                            <div class="card card-body bg-dark p-3 mb-3
                            <?php if( $voucher->status == 'accepted'): ?>
                                voucher-success
                            <?php elseif( $voucher->status == 'canceled'): ?>
                                voucher-danger
                            <?php else: ?>
                                voucher
                            <?php endif; ?> ">

                                <p class="my-auto voucher-text"><?php echo e($voucher->sale_date); ?> &emsp;<?php echo e($voucher->carts[0]->menu->store->name); ?> &nbsp; <sup class="badge badge-danger"> <?php echo e(count($voucher->carts)); ?> </sup></p>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\dohzay\resources\views/counter/orderHistory.blade.php ENDPATH**/ ?>