
<?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<nav class="navbar navbar-expand-md navbar-dark rounded fixed-top" style="background-color:#363636; margin-top:4.7em; z-index: 50 !important;">
    <div class="container">
        <nav class="navbar navbar-expand-md navbar-dark rounded" style="background-color:#292727; width:100%;">
            <form action="<?php echo e(route('filtertownship')); ?>" class="form-inline p-1 mx-auto">
                <label for="" class="text-white mr-3">Township:</label>
                <select name="township_id" id="township" class="form-control form-dark shadow" onchange="this.form.submit()">
                    <option value="0" <?php if($selected_township == 0 ): ?> selected <?php endif; ?> >All</option>
                    <?php $__currentLoopData = $townships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $township): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($township->id); ?>" <?php if($selected_township == $township->id ): ?> selected <?php endif; ?>><?php echo e($township->township); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
        </nav>
    </div>
</nav>



<div class="p-4 mt-3"></div>

<?php /**PATH D:\htdocs\dohzay\resources\views/inc/post-navbar.blade.php ENDPATH**/ ?>