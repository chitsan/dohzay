<!-- ADD Cart Modal -->
<div class="modal fade" id="addToCartModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-sm">
    <div class="modal-content bg-dark text-white">
        <div class="modal-header border-dark">
            <h3 class="modal-title" id="exampleModalLabel">Add To Cart</h3>
            <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form id="addForm">
        
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <div class="modal-body border-dark">
                <img id="img_url" src="" alt="food-image" class="img-fluid">
                <hr class="bg-secondary">
                <div class="form-group">
                    <label>Price</label>
                    <input type="hidden" class="form-control form-dark" id="food_id" name="id">
                    <input type="text" class="form-control form-dark shadow" id="unit_price" name="price" readonly>
                </div>
                <div class="form-group">
                    <label>Quantity</label>
                    <input type="number" class="form-control form-dark shadow" value="1" name="quantity" id="quantity" min="1" required>
                </div>
                <hr class="bg-secondary">
                <button type="submit" class="btn btn-outline-info btn-block">Add To Cart</button>
                <button type="button" class="btn btn-outline-secondary btn-block" data-dismiss="modal">Close</button>
            </div>
        </form>
    </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){

        $('.btn-add').on('click', function() {
            $('#addToCartModal').modal('show');


            $food_id = $(this).closest('div').find('.food-id');
            $img_url = $(this).closest('div').find('.img-url');
            $unit_price = $(this).closest('div').find('.unit-price');

            document.querySelector('#food_id').value = $food_id.val();
            document.querySelector('#img_url').src = $img_url.val();
            document.querySelector('#unit_price').value = $unit_price.val();
        });

    });

    $('#addForm').on('submit', function(e){
        e.preventDefault();

        $.ajax({
            type:"POST",
            url: "/carts/add",
            data: $('#addForm').serialize(),
            success: function (response) {
                console.log(response);
                document.querySelector('#quantity').value = 1;
                $('#addToCartModal').modal('hide')
                alert("Food Added");
            },
            error: function(error){
                console.log(error)
                // alert("Data Not Saved");
            }
        })
    });
</script>
<?php /**PATH D:\htdocs\dohzay\resources\views/modal/addToCard.blade.php ENDPATH**/ ?>