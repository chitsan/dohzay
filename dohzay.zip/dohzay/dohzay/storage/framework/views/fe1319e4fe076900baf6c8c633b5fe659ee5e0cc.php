<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card bg-dark text-white shadow text-center">
                <div class="card-header"><h3>Dashboard</h3></div>
                <div class="card-body">
                    <ul class="list-group shadow">
                    <a href="<?php echo e(route('post')); ?>"><li class="list-group-item bg-dark p-3">Post Foods</li></a>
                        <a href="<?php echo e(route('myMenuList')); ?>"><li class="list-group-item bg-dark p-3">View My Food List</li></a>
                        <a href="<?php echo e(route('viewTodayOrders')); ?>"><li class="list-group-item bg-dark p-3">View Orders</li></a>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\dohzay\resources\views/stores/myStore.blade.php ENDPATH**/ ?>