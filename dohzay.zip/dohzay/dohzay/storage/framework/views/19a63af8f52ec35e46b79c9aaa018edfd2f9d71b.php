<?php $__env->startSection('content'); ?>

<div class="container mt-3">
   <div class="row justify-content-center">
       <div class="col-lg-12">
            <h1 class="text-center text-white mt-5 mb-5">Mingalar par</h1>
       </div>
       <div class="col-lg-5 row">
            <div class="col-12 mb-3">
                <img src="<?php echo e(asset('storage/images/bander.png')); ?>" alt="bander.jpg" class="img-fluid">
                <hr>
            </div>
            <div class="col">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-info btn-block">Login</a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-info btn-block">Register</a>
            </div>
        </div>

   </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\dohzay\resources\views/welcome.blade.php ENDPATH**/ ?>