<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <?php echo $__env->make('modal.addToCart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-3">
                <div class="card bg-dark text-white shadow ">
                    <div class="card-header text-center">
                        <h3 class="mt-1"><?php echo e($food->name); ?></h5>
                    </div>

                    <div class="card-body ">
                        <?php $image = $food->images[0]->url ?>
                        <img src="<?php echo e(asset('storage/images/foods/'.$image)); ?>" alt="" class="img-fluid">
                    </div>
                    <div class="card-footer">
                        <div class="row no-gutters">
                            <div class="col mr-3">
                                <h5 class="btn btn-danger btn-block"><?php echo e($food->price); ?> Kyats</h5>
                            </div>
                            <div class="col">
                                <input type="hidden" name="food_id" value="<?php echo e($food->id); ?>" class="food-id">
                                <input type="hidden" name="img_url" value="<?php echo e(asset('storage/images/foods/'.$image)); ?>" class="img-url">
                                <input type="hidden" name="unit_price" value="<?php echo e($food->price); ?>" class="unit-price">
                                <a href="#" class="btn btn-outline-info btn-block btn-add" >
                                    Add To Cart
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="fixed-action-btn">
    <a href=" <?php echo e(route('counter')); ?>" class="btn-floating btn-large red mr-3">
       <i><img src="<?php echo e(asset('storage\images\cart.svg')); ?>" alt="cart" width="23em;"> </i>
    </a>
    
</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\dohzay\resources\views/posts/foods.blade.php ENDPATH**/ ?>