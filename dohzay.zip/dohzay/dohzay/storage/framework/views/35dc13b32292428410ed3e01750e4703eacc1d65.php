<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card bg-dark text-secondary shadow ">
                <div class="card-header text-center">
                    <h3 class="mt-1">Post Menu</h5>
                </div>

                <div class="card-body ">
                    <form method="POST" action="<?php echo e(route('postMenu')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="menu" class="col-form-label">Name</label>
                            <input id="menu" type="text" class="form-control form-dark shadow" name="menu" value="" required>

                        </div>

                        <div class="form-group">
                            <label for="price" class="col-form-label">Price</label>
                            <input id="price" type="number" class="form-control form-dark shadow" name="price" value="" required>
                        </div>

                        <div class="form-group">
                            <label for="image">Image</label><br>
                            <img src="<?php echo e(asset('storage/images/default.png')); ?>" id="image" class="shadow" style="width:30%;" />
                            <br>
                            <input type="file" id="file" class="btn btn-outline-dark btn-sm mt-1" name="image" onchange="thumbnail(this);" style="width:10em;"  required>
                        </div>

                        <div class="form-group">
                            <label for="description" class="col-form-label">Description</label>
                            <textarea id="description" class="form-control form-dark shadow" name="description" cols="30" rows="3" required ></textarea>
                        </div>
                        <hr>
                        <div class="form-group">
                                <button type="submit" class="btn btn-outline-info btn-block">
                                    <?php echo e(__('Post')); ?>

                                </button>
                                <a href="<?php echo e(route('store')); ?>" class="btn btn-outline-secondary btn-block">Back</a>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="application/javascript">
document.forms[0].addEventListener('submit', function( evt ) {
        var file = document.getElementById('file').files[0];

        if(file && file.size < 1485760) { // 1 MB (this size is in bytes)
            //Submit form
        } else {
            //Prevent default and display error
            alert('Image File is too big. Plz choose another image.');
            evt.preventDefault();

        }
    }, false);
    function thumbnail(input){
        var freader=new FileReader();
        freader.onload=function(e)
        {
            document.getElementById ("image").src=e.target.result;
        };
        freader.readAsDataURL(input.files[0]);
    }

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\dohzay\resources\views/menus/post.blade.php ENDPATH**/ ?>