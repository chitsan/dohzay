<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    public $timestamps = false;
    protected $table = 'cart';
    protected $fillable = [ 'menu_id', 'sale_id', 'price', 'quantity', 'status'];

    public function menu(){
        return $this->belongsTo('App\Menu');
    }

    public function voucher(){
        return $this->belongsTo('App\Voucher');
    }
    // public function carts(){
    //     return $this->hasMany('App\Cart');
    // }
}
