<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
    public $timestamps = false;
    protected $table = 'address';
    protected $fillable = [
        'store_id', 'township_id', 'address', 'location'
    ];

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function township(){
        return $this->belongsTo('App\Township');
    }

}
