<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cancel extends Model
{
    public $timestamps = false;
    protected $table = "cancel";
    protected $fillable = [ 'voucher_id', 'reason', 'cancel_date'];

    public function voucher(){
        return $this->belongsTo('App\Voucher');
    }
}
