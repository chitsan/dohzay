<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    public $timestamps = false;
    protected $table = 'menu';
    protected $fillable = [
        'menu', 'store_id', 'description', 'price', 'stock'
    ];

    public function store(){
        return $this->belongsTo('App\Store');
    }

    public function images(){
        return $this->belongsToMany('App\Image');
    }

    public function cart(){
        return $this->hasMany('App\Cart');
    }
}
