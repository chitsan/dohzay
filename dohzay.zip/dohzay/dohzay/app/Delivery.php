<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Delivery extends Model
{
    public $timestamps = false;
    protected $table = 'delivery';
    protected $fillable = [ 'voucher_id', 'township_id', 'price', 'message', 'phone', 'address', 'location'];

    public function voucher(){
        return $this->belongsTo('App\Voucher');
    }

    public function township(){
        return $this->belongsTo('App\Township');
    }
}
