<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Phone extends Model
{
    public $timestamps = false;
    protected $table = 'phone';
    protected $fillable = [
        'name', 'user_id'
    ];

    public function store(){
        return $this->belongsTo('App\Store');
    }
}
