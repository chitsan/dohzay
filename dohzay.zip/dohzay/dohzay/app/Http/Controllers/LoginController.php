<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\User;
use Auth;

class LoginController extends Controller
{

    public function index(){
        return view('users.login');
    }

    public function login(Request $request){
        // $account = $this->checkPhoneOrEmail($request);
        $email = $request->input('email');
        $password = $request->input('password');
        $user = User::where('email',$email)->first();
        if($user == NULL){
            return redirect()->route('login')->with('error','#1Incorrect user please check your email or password!');
        }else{
            if(Hash::check($password,$user->password)){
                $this->guard()->login($user);
                if($user->role == 'seller'){
                    return redirect()->route('store')->with('success','Login in successful');
                }else if($user->role == 'buyer'){
                    return redirect()->route('posts')->with('success','Login in successful');
                }

            }else{
                return redirect()->route('login')->with('error','Incorrect user please check your email or password!');
            }
        }

    }

    // public function checkPhoneOrEmail($request){
    //     $email = strpos($request->email, "@");
    //     if($email == NULL){
    //         return 'phone';
    //     }else{
    //         return 'email';
    //     }
    // }

    protected function guard(){
        return Auth::guard();
    }
}
