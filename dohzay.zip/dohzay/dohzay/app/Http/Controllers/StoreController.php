<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Store;
use App\Township;
use Auth;

class StoreController extends Controller
{

    public function index(){
        return view('stores.myStore');
    }

    public function create(){
        $data = [
            'townships' => Township::all()
        ];
        return view('stores.create',$data);
    }

    public function store(Request $request){
        $store = new Store;
        $store->name = $request->input('name');
        $store->user_id = Auth::id();
        $store->township_id = $request->input('township');
        $store->save();
        return redirect()->route('store')->with('success','Store Successfully Registered');
    }
}
