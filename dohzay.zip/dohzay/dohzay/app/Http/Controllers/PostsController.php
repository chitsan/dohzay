<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Store;
use App\menu;
use App\Township;
use DB;

class PostsController extends Controller
{
    public function index(){
        $menus = Menu::with('store')->get();
        $townships = Township::get();
        $data = [
            'selected_township' => 0,
            'townships' => $townships,
            'menus' => $menus
        ];

        return view('posts.menu',$data);
    }

    public function filtertownship(Request $request){
        $township_id = $request->get('township_id');
        if($township_id == 0){
            return redirect()->route('posts');
        }
        $menus = Menu::with('store')->get();
        $menus = $menus->filter(function($menu) use($township_id)
        {
            return $menu->store->township_id == $township_id;
        });
        // dd($township_id);
        // dd($menus);
        $townships = Township::get();
        $data = [
            'selected_township' => $township_id,
            'townships' => $townships,
            'menus' => $menus
        ];

        return view('posts.menu',$data);
    }
}
