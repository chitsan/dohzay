<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\User;
use Auth;

class RegisterController extends Controller
{
    public function create(){
        return view('users.register');
    }

    public function store(Request $request){
        // Insert Data Into User
        $user = new User;
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->phone = $request->input('phone');
        $user->password = Hash::make($request->input('password'));
        $user->role = $request->input('role');

        //Check if Email Already Exist
        if($this->checkEmailAlreadyExist($user)){
            return redirect()->route('register')->with('error','Customer with same email already exists in the system!');
        }

        //Check if Phone Already Exist
        if($this->checkPhoneAlreadyExist($user)){
            return redirect()->route('register')->with('error','Customer with same phone already exists in the system!');
        }

        $user->save();

        $this->guard()->login($user);
        // $user->sendEmailVerificationNotification();

        if($user->role == 'buyer'){
            return redirect()->route('posts');
        }else if($user->role == 'seller'){
            return redirect()->route('registerStore');
        }

    }

    // Make sure if email in unique
    // Return True if exist
    // Return Flase if not
    public function checkEmailAlreadyExist($user){
        if($user->email == NULL){
            return false;
        }else{
            $oldCustomer = User::where('email',$user->email)->first();
            if($oldCustomer != NULL){
                return true;
            }else{
                return false;
            }
        }

    }

    // Make sure if phone is unique
    // Return True if exist
    // Return Flase if not
    public function checkPhoneAlreadyExist($user){
        $oldCustomer = User::where('phone',$user->phone)->first();
        if($oldCustomer != NULL){
            return true;
        }else{
            return false;
        }
    }

    protected function guard(){
        return Auth::guard();
    }

}
