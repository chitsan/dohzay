<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use DB;
use Auth;
use App\User;
use App\Voucher;
use App\Cancel;


class CashiersController extends Controller
{
    public function todayOrders(){
        date_default_timezone_set("Asia/Yangon");
        $today_date = new DateTime("now" );
        $today_date = $today_date->format('Y-m-d');
        return redirect('/cashiers/viewOrders?order_date='.$today_date);
    }

    public function viewOrders(Request $request){
        $order_date = $request->get('order_date');
        $user = User::find(Auth::id());

        $vouchers = Voucher::where('store_id',$user->stores[0]->id)->whereDate('sale_date','=', $order_date)->orderBy('id','desc')->get();

        $data = [
            'vouchers' => $vouchers,
            'order_date' => $order_date
        ];

        return view('cashiers.viewOrders',$data);
    }

    public function viewVoucher($voucher_id){
        $voucher = Voucher::find($voucher_id);
        $data = [
            'voucher' => $voucher
        ];

        return view('cashiers.viewVoucher',$data);
    }

    public function acceptOrder(Request $request){
        $voucher = Voucher::find($request->input('voucher_id'));
        $voucher->status = "accepted";
        $voucher->save();
        date_default_timezone_set("Asia/Yangon");
        $today_date = new DateTime("now" );
        $today_date = $today_date->format('Y-m-d');
        return  redirect('/cashiers/viewOrders?order_date='.$today_date)->with('success','Order Successfully Accepted');
    }

    public function cancelOrder(Request $request){
        $voucher = Voucher::find($request->input('voucher_id'));
        $voucher->status = "canceled";
        $voucher->save();


        date_default_timezone_set("Asia/Yangon");
        $today_date = new DateTime("now" );
        $today_date = $today_date->format('Y-m-d');

        $cancel = new Cancel;
        $cancel->voucher_id = $voucher->id;
        $cancel->reason = $request->input('reason');
        $cancel->cancel_date = $today_date;
        $cancel->save();

        // return  redirect('/cashiers/viewOrders?order_date='.$today_date)->with('success','Order Successfully Canceled');
    }
}
