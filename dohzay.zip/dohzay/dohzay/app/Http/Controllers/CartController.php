<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Menu;
use App\Cart;
use App\Voucher;
use App\User;
use Auth;

class CartController extends Controller
{

    public function add(Request $request){
        $data = $this->populateData($request);

        // Init Objects
        $vouchers = Voucher::where([['user_id',$data['user']->id],['status','browsing']])->get();
        $voucher = new Voucher;
        $cart = new Cart;


        if($vouchers == NULL ){
            // Create New Voucher
            $voucher = $this->createVoucher($data);

            // Create New Cart
            $cart = $this->createCart($data,$voucher);
        }else{
            // Check voucher to make sure if menu is from same store
            $voucher = $this->checkExistingCart($data, $vouchers);
            if($voucher == NULL){
                // Create New Voucher
                $voucher = $this->createVoucher($data);

                // Create New Cart
                $cart = $this->createCart($data,$voucher);

            }else{
                 // Check Existing Cart
                $cart = Cart::where([['voucher_id',$voucher->id],['menu_id',$data['menu']->id]])->first();
                if($cart == NULL){

                    // Create New Cart
                    $cart = $this->createCart($data,$voucher);
                }

                $cart = $this->updateCart($data, $cart);
            }

        }

    }

    public function createVoucher($data){
        $voucher = new Voucher;
        $voucher->user_id = $data['user']->id;
        $voucher->store_id = $data['menu']->store->id;
        $voucher->sale_date = NULL;
        $voucher->status = 'browsing';
        $voucher->save();
        return $voucher;
    }

    public function createCart($data,$voucher){
        $cart = new Cart;
        $cart->menu_id = $data['menu']->id;
        $cart->voucher_id = $voucher->id;
        $cart->price = $data['menu']->price;
        $cart->quantity = $data['quantity'];
        $cart->save();
        return $cart;
    }

    public function updateCart($data,$cart){
        $cart->price = $data['menu']->price;
        $cart->quantity += $data['quantity'];
        $cart->save();
        return $cart;
    }

    public function populateData($request){
        $data = [
            'menu' => Menu::find($request->input('id')),
            'quantity' => $request->input('quantity'),
            'user'=> User::find(Auth::id())
        ];

        return $data;
    }

    public function checkExistingCart($data, $vouchers){
        foreach($vouchers as $voucher){
            if($voucher->carts[0]->menu->store->id == $data['menu']->store->id){
                return $voucher;
            }
        }

        return NULL;
    }
}
