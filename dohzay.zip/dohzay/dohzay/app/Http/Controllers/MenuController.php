<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Menu;
use App\Store;
use App\Image;
use Auth;

class MenuController extends Controller
{

    public function index(){
        $store = Store::where('user_id',Auth::id())->first();
        $menus = Menu::where('store_id',$store->id)->get();

        $data = [
            'menus' => $menus
        ];

        return view('menus.myMenuList',$data);
    }

    public function post(){
        return view('menus.post');
    }

    public function store(Request $request){
        $this->validate($request, [
            'image' => 'image|max:1999'
        ]);

        // Init User
        $user = User::find(Auth::id());

        // Get filename with extension
        $filenameWithExt = $request->file('image')->getClientOriginalName();

        // Get just the filename
        $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);

        // Get extension
        $extension = $request->file('image')->getClientOriginalExtension();

        // Create new filename
        $filenameToStore = $filename.'_'.time().'.'.$extension;

        // Upload Image
        // for local
        $path = $request->file('image')->storeAs('public/images/menu/',$filenameToStore);



        // Create Menu
        $menu = new Menu;
        $menu->menu = $request->input('menu');
        $menu->store_id = $user->stores[0]->id;
        $menu->price = $request->input('price');
        $menu->description = $request->input('description');
        $menu->stock = 'instock';

        // // Create Image
        $image = new Image;
        $image->url = $filenameToStore;


        // //Saving Data
        $menu->save(); // saving menu
        $menu->images()->save($image); // saving data into image and join table menu_image


        return redirect('/store')->with('success','Menu Successfully Posted');
    }
}
