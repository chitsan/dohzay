<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Voucher;
use App\Cart;
use App\Township;
use App\User;
use App\Delivery;
use Auth;
use DateTime;

class CounterController extends Controller
{
    public function index(){
        $user = User::find(Auth::id());
        $vouchers = Voucher::where([['user_id',$user->id],['status','browsing']])->get();
        $data = [
            'vouchers' => $vouchers
        ];

        return view('counter.beforeOrder',$data);
    }

    public function viewCart($voucher_id){
        $voucher = Voucher::find($voucher_id);
        $data = [
            'townships' => Township::get(),
            'user' => User::find(Auth::id()),
            'voucher' => $voucher
        ];

        return view('counter.viewCart',$data);
    }

    public function confirmOrder(Request $request){
        $data = $this->populateData($request);

        // Update Vocher
        $this->updateVoucher($data);

        // Save Delivery
        $this->saveDelivery($data);

        return redirect()->route('counter')->with('success','Order Successfully Made');
    }

    public function populateData($request){
        date_default_timezone_set("Asia/Yangon");
        $date = new DateTime("now" );
        $sale_date =  $date->format('Y-m-d');
        $data = [
            'voucher_id' => $request->voucher_id,
            'township_id' => $request->township_id,
            'price' => 0,
            'message' => $request->message,
            'phone' => $request->phone,
            'address' => $request->address,
            'location' => NULL,
            'sale_date' => $sale_date,
            'status' => 'ordered'
        ];

        return $data;
    }

    public function updateVoucher($data){
        $voucher = Voucher::find($data['voucher_id']);
        $voucher->sale_date = $data['sale_date'];
        $voucher->status = $data['status'];
        $voucher->save();
    }

    public function saveDelivery($data){
        $delivery = new Delivery;
        $delivery->voucher_id = $data['voucher_id'];
        $delivery->township_id = $data['township_id'];
        $delivery->price = $data['price'];
        $delivery->message = $data['message'];
        $delivery->phone = $data['phone'];
        $delivery->address = $data['address'];
        $delivery->location = $data['location'];
        $delivery->save();
    }

    public function orderHistory(){
        $user = User::find(Auth::id());
        $vouchers = Voucher::where('user_id',$user->id)
        ->where( function($q){
            $q->where('status','order')->orWhere('status','accepted')->orWhere('status','canceled');
        })
        ->get();
        $data = [
            'vouchers' => $vouchers
        ];

        return view('counter.orderHistory',$data);
    }

    public function detailOrderHistory($voucher_id){
        $voucher = Voucher::find($voucher_id);
        $data = [
            'townships' => Township::get(),
            'user' => User::find(Auth::id()),
            'voucher' => $voucher
        ];

        return view('counter.detailOrderHistory',$data);
    }
}
