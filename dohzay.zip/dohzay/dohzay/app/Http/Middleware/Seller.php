<?php

namespace App\Http\Middleware;


use Closure;
use Auth;

class Seller
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }


        if (Auth::user()->role != "seller") {
            return redirect()->route('home');
        }

        $response = $next($request);

        // Perform action
        return $response;
    }
}
