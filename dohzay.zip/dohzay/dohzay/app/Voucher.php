<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Voucher extends Model
{
    public $timestamps = false;
    protected $table = 'vouchers';
    protected $fillable = [ 'user_id', 'store_id', 'sale_date', 'status'];

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function store(){
        return $this->belongsTo('App\Store');
    }

    public function carts(){
        return $this->hasMany('App\Cart');
    }

    public function delivery(){
        return $this->hasOne('App\Delivery');
    }

    public function cancel(){
        return $this->hasOne('App\Cancel');
    }
}
