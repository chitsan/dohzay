<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Township extends Model
{
    public $timestamps = false;
    protected $table = 'townships';
    protected $fillable = [
        'name', 'township', 'location'
    ];

    public function address(){
        return $this->hasMany('App\Address');
    }

    public function store(){
        return $this->hasMany('App\Store');
    }

    public function deliveries(){
        return $this->hasMany('App\Delivery');
    }
}
