<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Store extends Model
{
    public $timestamps = false;
    protected $table = 'store';
    protected $fillable = [
        'name', 'user_id', 'township_id'
    ];

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function phones(){
        return $this->hasMany('App\Phone');
    }

    public function township(){
        return $this->belongsTo('App\Township');
    }

    public function menu(){
        return $this->hasMany('App\Menu');
    }

    public function vouchers(){
        return $this->hasMany('App\Voucher');
    }


}
