@extends('layouts.app')

@section('content')

<div class="container mt-3">
   <div class="row justify-content-center">
       <div class="col-lg-12">
            <h1 class="text-center text-white mt-5 mb-5">Mingalar par</h1>
       </div>
       <div class="col-lg-5 row">
            <div class="col-12 mb-3">
                <img src="{{ asset('storage/images/bander.png') }}" alt="bander.jpg" class="img-fluid">
                <hr>
            </div>
            <div class="col">
                <a href="{{ route('login') }}" class="btn btn-outline-info btn-block">Login</a>
            </div>
            <div class="col">
                <a href="{{ route('register') }}" class="btn btn-outline-info btn-block">Register</a>
            </div>
        </div>

   </div>
</div>

@endsection
