@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            @include('inc.messages')
            <div class="card bg-dark text-white shadow text-center">
                <div class="card-header"><h3>Dashboard</h3></div>
                <div class="card-body">
                    <ul class="list-group shadow">
                    <a href="{{ route('post') }}"><li class="list-group-item bg-dark p-3">Post Foods</li></a>
                        <a href="{{ route('myMenuList') }}"><li class="list-group-item bg-dark p-3">View My Food List</li></a>
                        <a href="{{ route('viewTodayOrders') }}"><li class="list-group-item bg-dark p-3">View Orders</li></a>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
