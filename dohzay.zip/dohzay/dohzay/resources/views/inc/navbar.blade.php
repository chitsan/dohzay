
@include('inc.nav')

<div class="p-4"></div>

