
@include('inc.nav')

<nav class="navbar navbar-expand-md navbar-dark rounded fixed-top" style="background-color:#363636; margin-top:4.7em; z-index: 50 !important;">
    <div class="container">
        <nav class="navbar navbar-expand-md navbar-dark rounded" style="background-color:#292727; width:100%;">
            <form action="{{ route('filtertownship') }}" class="form-inline p-1 mx-auto">
                <label for="" class="text-white mr-3">Township:</label>
                <select name="township_id" id="township" class="form-control form-dark shadow" onchange="this.form.submit()">
                    <option value="0" @if ($selected_township == 0 ) selected @endif >All</option>
                    @foreach($townships as $township)
                        <option value="{{$township->id}}" @if ($selected_township == $township->id ) selected @endif>{{$township->township}}</option>
                    @endforeach
                </select>
            </form>
        </nav>
    </div>
</nav>



<div class="p-4 mt-3"></div>

