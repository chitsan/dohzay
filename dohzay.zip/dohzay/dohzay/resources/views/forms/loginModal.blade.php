<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
    Launch demo modal
  </button>

  <!-- Modal -->
  <form method="POST" action="{{ route('login') }}" class="modal fade mt-5" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="loginModel" aria-hidden="true">
    @csrf
    <div class="modal-dialog modal-sm text-white">
      <div class="modal-content bg-dark ">
        <div class="modal-header justify-content-center border-dark">
          <h3 class="modal-title text-center font-weight-bold" id="login">Login</h3>
        </div>
        <div class="modal-body border-dark">
            <div class="form-group">
                <label for="email">{{ __('E-Mail Address') }}</label>
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                @error('email')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group">
                <label for="password">{{ __('Password') }}</label>
                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                @error('password')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group float-right">
                {{-- <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                    <label class="form-check-label text-left" for="remember">
                        {{ __('Remember Me') }}
                    </label>
                </div> --}}
                @if (Route::has('password.request'))
                    <a class="btn btn-link" href="{{ route('password.request') }}">
                        {{ __('Forgot Your Password?') }}
                    </a>
                @endif
            </div>
        </div>
        <div class="modal-footer border-dark">
            <button type="submit" class="btn btn-primary">
                {{ __('Login') }}
            </button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </form>
