@extends('layouts.post')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-12 mt-5">
            @include('modal.addToCart')
        </div>
        @foreach($menus as $menu)
            <div class="col-md-4 mb-3">
                <div class="card bg-dark text-white shadow ">
                    <div class="card-header text-center">
                        <h3 class="mt-1">{{$menu->menu}}</h5>
                    </div>

                    <div class="card-body ">
                        @php $image = $menu->images[0]->url @endphp
                        <img src="{{asset('storage/images/menus/'.$image)}}" alt="" class="img-fluid">
                    </div>
                    <div class="card-footer">
                        <div class="row no-gutters">
                            <div class="col mr-3">
                                <h5 class="btn btn-danger btn-block">{{$menu->price}} Kyats</h5>
                            </div>
                            <div class="col">
                                <input type="hidden" name="menu_id" value="{{$menu->id}}" class="menu-id">
                                <input type="hidden" name="img_url" value="{{asset('storage/images/menus/'.$image)}}" class="img-url">
                                <input type="hidden" name="unit_price" value="{{$menu->price}}" class="unit-price">
                                <a href="#" class="btn btn-outline-info btn-block btn-add" >
                                    Add To Cart
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

<div class="fixed-action-btn">
    <a href=" {{ route('counter') }}" class="btn-floating btn-large red mr-3">
       <i><img src="{{ asset('storage\images\cart.svg') }}" alt="cart" width="23em;"> </i>
    </a>
    {{-- <sup class="badge badge-light noti-number">2</sup> --}}
</div>



@endsection

