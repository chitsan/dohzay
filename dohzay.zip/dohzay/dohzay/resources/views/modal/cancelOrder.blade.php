<!-- ADD Cart Modal -->
<div class="modal fade" id="cancelOrderModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-sm">
    <div class="modal-content bg-dark text-white">
        <div class="modal-header border-dark">
            <h3 class="modal-title" id="exampleModalLabel">Cancel Order</h3>
            <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form id="cancelOrderForm">
            @csrf
            @method('post')
            <div class="modal-body border-dark text-left">
                <div class="form-group">
                    <label>Reason</label>
                    <input type="hidden" class="form-control form-dark" name="voucher_id" value="{{ $voucher->id }}">
                    <textarea name="reason" id="" cols="10" rows="5" class="form-control form-dark shadow" required></textarea>
                </div>
                <hr class="bg-secondary">
                <button type="submit" class="btn btn-outline-danger btn-block">Cancel Order</button>
                <button type="button" class="btn btn-outline-secondary btn-block" data-dismiss="modal">Close</button>
            </div>
        </form>
    </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){

        $('.btn-cancel').on('click', function() {
            $('#cancelOrderModal').modal('show');
        });

    });

    $('#cancelOrderForm').on('submit', function(e){
        e.preventDefault();

        $.ajax({
            type:"POST",
            url: "/cashiers/cancelOrder",
            data: $('#cancelOrderForm').serialize(),
            success: function (response) {
                console.log(response);
                $('#cancelOrderModal').modal('hide')
                alert("Order Successfully Canceled");
                location.assign('/cashiers/viewTodayOrders');
            },
            error: function(error){
                console.log(error)
                // alert("Data Not Saved");
            }
        })
    });
</script>
