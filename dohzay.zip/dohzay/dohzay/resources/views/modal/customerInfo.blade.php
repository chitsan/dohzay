<!-- ADD Cart Modal -->
<div class="modal fade" id="customerInfo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-sm">
    <div class="modal-content bg-dark text-white">
        <div class="modal-header border-dark">
            <h3 class="modal-title" id="exampleModalLabel">Customer Info</h3>
            <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>


        <div class="modal-body border-dark text-left">
            <p class="alert bg-danger text-white">Customer:&nbsp;{{ $voucher->user->name }}</p>
            <p class="alert bg-danger text-white">Phone:&nbsp;{{ $voucher->delivery->phone }}</p>
            <p class="alert bg-danger text-white">Township:&nbsp;{{ $voucher->delivery->township->township }}</p>
            <p class="alert bg-danger text-white">Address:&nbsp;{{ $voucher->delivery->address }}</p>
            <button type="button" class="btn btn-outline-secondary btn-block" data-dismiss="modal">Close</button>
        </div>

    </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){

        $('.btn-customer').on('click', function() {
            $('#customerInfo').modal('show');
        });

    });
</script>
