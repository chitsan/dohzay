@extends('layouts.app')

@section('content')
@php $total = 0 @endphp
<div class="container pt-5">
    <div class="row justify-content-center text-center">
        <div class="col-md-12">
            @include('inc.messages')
            @include('modal.customerInfo')
            @include('modal.cancelOrder')
            <div class="card bg-dark text-secondary">
                <div class="card-header">
                    <div class="form-inline justify-content-center">
                        <h2 class="text-right mt-2 mr-2"> Voucher</h2>

                        <a href=" {{ route('viewTodayOrders') }}" class="btn btn-danger btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14.9" height="12.2" viewBox="0 0 24.9 22.2">
                                <g id="back" transform="translate(-821.1 -1467.9)">
                                  <path id="Path_481" data-name="Path 481" d="M846,1482.7a16.165,16.165,0,0,1-1.8,6.2c0,.1-.1.2-.1.3a.758.758,0,0,1-.2.4c-.1.1-.1.2-.2.3-.1.2-.2.2-.4.2a.353.353,0,0,1-.4-.4v-.7c0-.6.1-1.2.1-1.7a18.088,18.088,0,0,0-.2-2.5,8.392,8.392,0,0,0-.7-1.9,7.553,7.553,0,0,0-1.1-1.4,7.839,7.839,0,0,0-1.5-1,9.5,9.5,0,0,0-1.8-.6l-2.1-.3a17.728,17.728,0,0,0-2.4-.1H830v3.5a.851.851,0,0,1-1.5.6l-7.1-7.1a.75.75,0,0,1,0-1.2l7.1-7.1a.9.9,0,0,1,1.5.6v3.5h3.1c6.6,0,10.6,1.9,12.1,5.6A14.635,14.635,0,0,1,846,1482.7Z" fill="#fff"/>
                                </g>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="card-body table-responsive">
                    @foreach($voucher->carts as $cart) @php $total += ($cart->quantity) * ($cart->price) @endphp @endforeach
                    <form method="post" action="{{ route('acceptOrder') }}" class="mx-auto">
                        @csrf
                        <input type="hidden" name="voucher_id" value="{{$voucher->id}}" >
                        <span class="btn bg-danger text-white mr-1 mt-1">Total: {{ $total }} Kyats</span>
                        <a href="#" class="btn btn-danger btn-customer mr-1 mt-1">Customer</a>
                        @if ($voucher->status == 'ordered')
                            <button type="submit" class="btn btn-danger mr-1 mt-1">Accept</button>
                            <a href="#" class="btn btn-danger btn-cancel mr-1 mt-1">Cancel</a>
                        @endif
                        <a href="{{ route('viewTodayOrders') }}" class="btn btn-dark mr-1 mt-1">Back</a>
                    </form><hr>
                    <table class="table table-borderless table-dark">
                        <thead>
                          <tr class="font-weight-bold">
                            <th scope="col">Image</th>
                            <th scope="col">Name</th>
                            <th scope="col">Unit Price</th>
                            <th scope="col">Quantity</th>
                          </tr>
                        </thead>
                        <tbody>
                            @foreach($voucher->carts as $cart)
                            <tr>

                                <td><img src=" {{ asset('storage/images/menus/'.$cart->menu->images[0]->url) }} " alt="Food Image" width="50em;"></td>
                                <td>{{ $cart->menu->menu }}</td>
                                <td>{{ $cart->price }} Kyats</td>
                                <td>{{ $cart->quantity }}</td>
                              </tr>


                            @endforeach


                        </tbody>
                      </table>


                </div>
            </div>
        </div>
    </div>
</div>
@endsection
