CREATE TABLE `address` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `township_id` int(11) NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `cancel` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `voucher_id` int(11) NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cancel_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



INSERT INTO `cancel` (`id`, `voucher_id`, `reason`, `cancel_date`) VALUES
(1, 1, 'Cancel', '2020-05-27'),
(2, 1, 'Cancel', '2020-05-27'),
(3, 1, 'Cancel', '2020-05-27');



CREATE TABLE `cart` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `menu_id` int(11) NOT NULL,
  `voucher_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



INSERT INTO `cart` (`id`, `menu_id`, `voucher_id`, `price`, `quantity`) VALUES
(1, 1, 1, 1000, 2),
(2, 6, 2, 7000, 2),
(3, 5, 1, 700, 4);


CREATE TABLE `delivery` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `voucher_id` int(11) NOT NULL,
  `township_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



INSERT INTO `delivery` (`id`, `voucher_id`, `township_id`, `price`, `message`, `phone`, `address`, `location`) VALUES
(1, 1, 2, 0, 'Order', '09 973124523', 'No 83, Myanmar Gon Yi Road.', NULL),
(2, 1, 2, 0, 'Order', '09 973124523', 'No 83, Myanma Gon Yi Road, Yangon.', NULL);


CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `images` (`id`, `url`) VALUES
(1, 'bander_1590215239_1590297155.jpg'),
(2, 'burger-with-sunny-side-up-on-white-surface-2293537_1590228186_1590297182.jpg'),
(3, 'burrito-chicken-delicious-dinner-461198_1590228218_1590297211.jpg'),
(4, 'close-up-photo-of-a-cheese-burger-1633578_1590228251_1590297235.jpg'),
(5, 'huyen-nguyen-l4qImHQIg2Q-unsplash_1590228275_1590297254.jpg'),
(6, 'aung soe pizza_1590419714.jpg'),
(7, 'yaw ma pizza_1590419733.jpg'),
(8, 'zaw gyi pizza_1590419754.jpg');


CREATE TABLE `image_menu` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `image_menu` (`id`, `image_id`, `menu_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4),
(5, 5, 5),
(6, 6, 6),
(7, 7, 7),
(8, 8, 8);

CREATE TABLE `menu` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `menu` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_id` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `stock` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `menu` (`id`, `menu`, `store_id`, `description`, `price`, `stock`) VALUES
(1, 'Kalar Hin', 1, 'Kalar Hin', 1000, 'instock'),
(2, 'Egg Burger', 1, 'Egg Burger', 1000, 'instock'),
(3, 'Chicken Burrito', 1, 'Chicken Burrito', 1500, 'instock'),
(4, 'Cheese Burger', 1, 'Cheese Burger', 2000, 'instock'),
(5, 'Cookies', 1, 'Cookies', 700, 'instock'),
(6, 'Aung Soe Pizza', 2, 'Aung Soe Pizza', 7000, 'instock'),
(7, 'Yaw Ma Pizza', 2, 'Yaw Ma Pizza', 10000, 'instock'),
(8, 'Zaw Gyi Pizza', 2, 'Zaw Gyi Pizza', 10000, 'instock');


CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_05_19_102645_create_store', 1),
(5, '2020_05_19_105923_create_images', 1),
(6, '2020_05_19_120419_create_township', 1),
(7, '2020_05_19_120555_create_address', 1),
(8, '2020_05_19_120903_create_phone', 1),
(10, '2020_05_23_051320_create_food_image', 1),
(18, '2020_05_26_145059_create_delivery', 3),
(19, '2020_05_24_050427_create_vouchers', 4),
(20, '2020_05_27_160644_create_cancel', 5),
(21, '2020_05_23_051312_create_menu', 6),
(23, '2020_05_24_050453_create_cart', 8),
(24, '2020_05_23_051320_create_image_menu', 9);


CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `phone` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `store` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `township_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `store` (`id`, `name`, `user_id`, `township_id`) VALUES
(1, 'Gotham Joint', 1, 2),
(2, 'Luigi', 3, 7);

CREATE TABLE `townships` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `township` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `townships` (`id`, `township`, `location`) VALUES
(1, 'Pazundawn', NULL),
(2, 'Mingalar Taung Nyunt', NULL),
(3, 'Tamwe', NULL),
(4, 'Dawbon', NULL),
(5, 'Takayka', NULL),
(6, 'Dagon', NULL),
(7, 'Latha', NULL),
(8, 'Lanmadaw', NULL),
(9, 'Pabeden', NULL),
(10, 'Kyauktada', NULL),
(11, 'Ahlone', NULL),
(12, 'Kyimyitdine', NULL),
(13, 'Sanchaung', NULL),
(14, 'Kamaryut', NULL),
(15, 'Hlaing', NULL),
(16, 'Mayangon', NULL),
(17, 'Tamine', NULL),
(18, 'Insein', NULL),
(19, 'Bahan', NULL),
(20, 'Yankin', NULL),
(21, 'Kabar Aye', NULL),
(22, 'Thingagyun', NULL),
(23, 'Thuwana', NULL),
(24, 'South Okkala', NULL),
(25, 'North Dagon', NULL),
(26, 'North Okkala', NULL),
(27, 'Shwe Pauk Kan', NULL),
(28, 'Mingalardon', NULL),
(29, 'Botahtaung', NULL);

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `users` (`id`, `name`, `email`, `phone`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Ye Thiha', 'phantomthiha@gmail.com', '09973124523', NULL, '$2y$10$D2tnquOWH/D5RidBOESxE.oRtmZCkaa2kUp5E4E2ceFzqNeuUXfz2', 'seller', NULL, '2020-05-23 22:41:17', '2020-05-23 22:41:17'),
(2, 'Ye Thiha', 'mightycryptowall@gmail.com', '09 795144775', NULL, '$2y$10$t8qp4VAJm.JNax1Kx3BNGOrXt5QbnCQAepK2MdZEzVajMepcz1qNO', 'buyer', NULL, '2020-05-23 22:44:47', '2020-05-23 22:44:47'),
(3, 'Johny Goldman', 'johnygoldman@gmail.com', '0973124526', NULL, '$2y$10$DdX5WQU6bd6GcmOAAlsRiOyGRZxtZG7widbawpSEUVU8yyyww/oyO', 'seller', NULL, '2020-05-25 08:35:41', '2020-05-25 08:35:41'),
(4, 'Gold D Roger', 'roger@gmail.com', '09972424242', NULL, '$2y$10$mAx4byfzYsh0RZ4zUeePtu8GOJLEBmrOFn3bqQ.RxnKz74C9gGXjm', 'buyer', NULL, '2020-05-28 09:23:21', '2020-05-28 09:23:21');


CREATE TABLE `vouchers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `sale_date` date DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `vouchers` (`id`, `user_id`, `store_id`, `sale_date`, `status`) VALUES
(1, 2, 1, '2020-05-27', 'canceled'),
(2, 2, 2, NULL, 'browsing');

ALTER TABLE `address`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `cancel`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `delivery`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `image_menu`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

ALTER TABLE `phone`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `store`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `townships`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`);

ALTER TABLE `vouchers`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `address`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `cancel`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `cart`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `delivery`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `image_menu`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `menu`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

ALTER TABLE `phone`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `store`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `townships`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `vouchers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

